export const MATILDA_TOTAL_PAGES = 60;

// Matilda's story doesn't have chapters
export const MATILDA_CHAPTERS = [];