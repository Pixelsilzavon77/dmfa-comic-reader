export interface SpeciesAttribute {
  label: string;
  value: string;
}

export interface SpeciesSection {
  title: string;
  content: string;
}

export interface Species {
  name: string;
  type: 'race' | 'class';
  image?: string;
  attributes: SpeciesAttribute[];
  sections: SpeciesSection[];
}

const placeholderContent = 'Information about this species is not yet available.';
const placeholderSection = [{ title: 'Overview', content: placeholderContent }];

export const demonologyData: Species[] = [
  // Races
  {
    name: 'Angel',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Angel.gif',
    attributes: [
      { label: 'Wings', value: 'Feather-based' },
      { label: 'Markings', value: 'Bright coloured' },
      { label: 'Magic', value: 'Light-oriented' },
      { label: 'Abilities', value: 'Heightened speed/senses' },
      { label: 'Diet', value: 'Omnivorous (lean carnivorous)' },
      { label: 'Lifespan', value: 'Up to 1500 years' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `While not as actively rampaging the countryside as their demonic cousins, a fair deal of trouble has been caused at the hands of the angel race. This is primarily due to the angel-races tactics: where a demon would go in themselves and burn a city to the ground, an angel would manipulate it so that someone else would do the work for them. It should be noted that the "angel" term is primarily aesthetic. With feathered wings and light-based magic, the angel race is a master of convincing other races of their good intentions. However deep beneath the lovely exterier often lies the mind that can rival even the most devious of the demon-race.

The angel race's entire mantra seems to focus on power. Some will choose the path of knowledge and can often be seen as the protectors of large libraries, where others may become a guardian of a village where the villagers offer them tribune for their service. There have been many cases of kindly angels but usually temptations are too strong a force and most angels cannot resist an offer of an item of great power or a scheme involving a gain of some sort.

There are no known cities belonging to the angel-race and by nature the entire race seems to be highly solitary unless a certain cause brings them together. Angels of a feather seem to not flock together as they are highly competitive and constantly try to get the upper hand of the other, causing massive fights.`
      },
      {
        title: 'History',
        content: `The angel race first appeared around the same time as the demon race, and it is almost rumoured that they were caused from a similar event and are merely the two magical representations of light and darkness. When the first council was created, it was an angel-race who was behind most of the diplomacy and acting between races that would often be at edge with eachother. Most well-known historic figures in the angel race had something to do with diplomatic means despite the many tragic events that have unfolded at the hands of a craftier angel. Some speculate this is due to future generations of angels removing the evidence of the previous incidents from general history in order to further gain their own glory.`
      },
      {
        title: 'Strengths',
        content: `Angels are generally much faster in both reflexes and thinking than many other races. Many are also capable of making their skin razor sharp and hard. With the aid of light-magic, many of them are the master of some highly powerful spells.`
      },
      {
        title: 'Weaknesses',
        content: `As mentioned, most Angels cannot resist the lure of power and will often offer aid in exchange for items of power. The angel race is often harder to find weak-points as they tend to work in the background of their schemes and simply disappear when things go wrong.`
      },
      {
        title: 'Notable Figure: Akaen',
        content: `Age 612, Akaen is the current angel-representative of the Beings/Creature council and possibly one of the nicest members of the council(or at least appears to be). Charismatic, curious, and containing a sharp wit, he often ends up acting as the one to smooth out the worst wrinkles in arguments between races. It is also known he is one of the largest investors in many of the technologies beings have been making. One could almost say a good deal of the industrial age in Furrae was thanks to Akaen's support.`
      }
    ]
  },
  {
    name: 'Demon',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Demon.gif',
    attributes: [
      { label: 'Wings', value: 'Bat-based' },
      { label: 'Key Features', value: 'Horns' },
      { label: 'Markings', value: 'Dark coloured' },
      { label: 'Magic', value: 'Dark-oriented' },
      { label: 'Abilities', value: 'Heightened speed/senses' },
      { label: 'Lifespan', value: 'Up to 1500 years' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `The demon race is probably one of the more commonly known of the creature races. Most likely this is due to their tendancy towards showing off and causing great amounts of trouble. Unlike their angelic cousins, the demon race is often up front and to the point, and prefer to go in and handle things themselves (usually violent) than enact any form of diplomacy. The wings of a demon will usually be batlike or leathery, and it isnt uncommon for them to have horns and claws. And while there are plenty of cases of good-natured demons, by and large the race isn't that afraid to use them whenever the chance arises.

Like their light-magic counterparts, Demons seem to go by a rule of power. However their power seems to derive more from chaotic forces and so it isn't uncommon for many demons to go about doing it in the easiest way necessary. While most of the creature races get along well with eachother, arguments and battles over a rogue demon intruding on another creatures area and messing it up isn't uncommon.

There are no known cities of the demon race, though small clans and communities seem to exist. Most demons seem to share a sense of family and will often band together for long periods of time. Even afterwards demons seem to share a lot more close ties to their kin.`
      },
      {
        title: 'History',
        content: `The demon race first appeared around the same time as the angel race, and it is almost rumoured that they were caused from a similar event and are merely the two magical representations of light and darkness. While the history books have many cases of demon's influencing history (often in a very bad way), it is also said that it was the demon race who was one of the prime supporters of a Creature/Being council. As a side mention, many of the greatest spies and assissins in Furrae's history are attributed to the demon race. Whatever their motives may be, the demon race does what they do well.`
      },
      {
        title: 'Strengths',
        content: `Most demons have lightning fast reflexes and the ability to turn their skin razor sharp and diamond hard. They also seem to have an almost unlimited supply of endurance to aid them in whatever they hope to achieve. The masters of dark magic, it isn't uncommon for them to seem to almost disapeer into the shadows.`
      },
      {
        title: 'Weaknesses',
        content: `As a demon grows older, it gets a lot harder to kill. Some even wonder how demons die in general since near the end of their lives they often seem indestructable by normal means. However fast and strong they may be though, most demons can be killed by various means if their opponent is clever or strong enough. Because of this, most demons don't have a real notion of revenge or vengeance if one of their own kind is slain. After all, by their own belief system, if someone is able to defeat them, that other creature or being is obviously worthy.`
      },
      {
        title: 'Notable Figure: Nicky',
        content: `Age 56,720, Nicky is by far the oldest demon in the demon-race. One of a demons goal is often to achieve immortality or extended life. Most demons are easily able to add a few thousand years to their lives. However Nicky, by fate or by accident, managed to come across some force so powerful that she has been able to retain the same youthful appearance without any signs of change for well over the average years. Unfortunately as a side effect, she has also lost her ability to retain the wisdom that would come with age and thus A) Has no rememberance or knowledge of how she came into this power and B) loses all memories older than 100 years. This can be seen as a blessing or a curse given the point of view.`
      }
    ]
  },
  {
    name: 'Mer',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Mer.gif',
    attributes: [
      { label: 'Eyes', value: 'Lidless' },
      { label: 'Key Features', value: 'Large fins, multiple spines' },
      { label: 'Magic', value: 'Water-oriented' },
      { label: 'Lifespan', value: 'Unknown' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `Like the Insectis race, there is not much actually known about the Mer race as the majority of the race tends to keep below in secret cities out of sight of normal means. However unlike the Insectis race, the Mer race shows a great deal more curiosity and interest in the outside world and has recently begun to come more in contact with the land-dwelling species.

Masters of the oceans, the Mer hold the concept that whatever is beneath the water belongs to them, and as a result any ship that is sunk becomes their property and any person who is foolish enough to try to adventure under the waves often finds themselves at their mercy. The Mer also seem to have a habit of kidnapping those who go swimming at the beach now and again though the Mer race denies it everytime. In order to avoid any hassle, many ships will often charter deals with the Mer race as "insurance" and very recently the Mer race has allowed some supervised visits to one of their cities though the actual trip there was shrouded in mystery.

While very little is known about the Mer race, it is known they are run via royalty. Another thing is that the Mer race have two sets of hands; the outer resembling large webbed fingers which act as fins and then a second set beneath inside which is smaller and used for gripping and fine details. The Mer's language is untranslatable, as it sounds more like strange vibrations due to the lack of air to speak. Though many Mer are able to train the vibrations to mimic other languages.

The Mer race is able to alter its form slightly in order to move about on land by taking a serpantine lower half...however they tend to avoid being on land for more than a few days without some visits back to water. An overall interesting race, there is still a lot left unknown.`
      },
      {
        title: 'History',
        content: `There is little recorded history of the Mer race to the outside world. They joined the Councils only recently and seem to have a strong ally of the Insectis race. This is likely due to that they both run self-contained kingdoms that have no real basis of infringing on eachother. The Mer race seems quite happy to keep to their watery kingdom as the Insectis to their underground. The only real recorded event in normal history is an old legend of a Mer helping to save a ship carrying precious cargo that was stranded on the ocean. In exchange for her aid, she asked that the Captain promise to be hers and to live with her in her kingdom. Agreeing, the Mer created a current that quickly took the ship to a nearby harbor. Once at shore however the Captain took off inland along with his crew and the cargo never intending to keep his deal. After a week none of the crew was left alive, as each seemed to have drowned in his sleep.`
      },
      {
        title: 'Strengths',
        content: `In the water, the Mer are a force to be reckoned with. Very fast, and a few have poisoned barbs, they wield water magic unmatched by any race with the possible exception of Fae.`
      },
      {
        title: 'Weaknesses',
        content: `On land they are much weaker, and seem to dislike being out in the sunlight for very long.`
      },
      {
        title: 'Notable Figure: Scarlet',
        content: `No one is quite sure of her age, or much about her. When the Mer race first allowed someone to visit their realm, the being was allowed to bring a film camera to document what he saw. Overnight the entire world of Furrae became entranced by the seemingly magical kingdom beneath the ocean and one notable sight was a particular Mer who allowed a tour of the palace. Later it was discovered that she was actually one of the royal children though her name was completly unpronouncable. She was nicknamed "Scarlet" topside due to her colouring and became somewhat an icon celebrity when it comes to the Mer race. That is really all that is known about her.`
      }
    ]
  },
  {
    name: 'Cubi (Succubus/Incubus)',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Cubi.gif',
    attributes: [
        { label: 'Primary Trait', value: 'Highly morphable appearance, emotional manipulation.' },
        { label: 'Key Features', value: 'Multiple sets of wings, unalterable clan markings.' },
        { label: 'Magic', value: 'Skilled in both light and dark magic.' },
        { label: 'Lifespan', value: 'Up to 1000 years, extendable with power.' },
        { label: 'Sustenance', value: 'Absorbing emotional energy, dream energy, or souls.' },
    ],
    sections: [
        {
            title: 'General Overview',
            content: `The Cubi race seems to fall into a strange sideline between the Angel and the Demon race...so much that it is often a joke that the Cubi race was created because the Angel and Demon race got along "too" well. Whatever the case may be, the Cubi are both highly skilled in light and dark magic and their wings will come in a variety of styles. Though perhaps the most unique feature of this race is that they have a second set of wings atop their head. It is unsure if they are simply decoration or actually do anything(no Cubi would dare let them get cut off alive), though they manifest around the same time a Cubi comes into power. There is also rumours that upon reaching a particular level of power, a Cubi gains a third set of wings. This is currently in debates though among Creatures as if any do exist, they tend to keep well-hidden.

Unlike many of the other races, Cubi do no need to eat to gain energy. In fact their primary method of gaining power and energy is by either harnessing the emotions of beings and creatures around them, entering their dreams and harnessing energy that way, or just out and out stealing the soul out of some hapless beings body. And while many Cubi are content to live lives peacefully simply absorbing energy, quite a few Cubi will gladly go for the power boost that requires a bit of cruelty but gets more results a lot faster.

In a sense the Cubi are what they eat, as they are very emotional creatures. They also seem to have a soft spot for the finer things in life so seeing a cubi Actor or a Cubi working for a powerful rich Lord isn't uncommon. Much like their demonic cousins, Cubis seem intent on gaining power as it not only increases their lifespan and allows them special abilities, it is a prime focus of their clans goals. All cubis belong to particular clans, and their symbol appears soon after the Cubi begins to use magic. It is the one marking a Cubi can't alter thus a good way to spot a cubi would be to find their marking.`
        },
        {
            title: 'History',
            content: `Despite their ability to outlive many other creatures, the Cubi race is relatively young. Their first notable appearance was around the time Beings began developing civilizations so many Creatures assume the Cubi are a somewhat biproduct of this. Regardless, many Cubi have been the inspirational muses to some great achievement...though many more Cubi have been the result of some very nasty events.`
        },
        {
            title: 'Strengths',
            content: `Cubi are the masters of altering their physical appearance, and their wings can often sprout tendrils (a good note would be that certain clans have particular tendril styles as well as a marking). They are masters of emotional manipulation and can often read minds. They are strongest when in the dreams of others and even outside show a good amount of skills.`
        },
        {
            title: 'Weaknesses',
            content: `Cubi tend to be highly inexperienced at battles and highly egotistical... thus often leading them to underestimate their opponents. They also tend to have short attention spans. Most Cubi can die from normal means unless they are a certain power level.`
        },
        {
            title: "Notable Figure: Fa'Lina",
            content: `Age 9,288, Fa'Lina is the head-mistress of the Succubus and Incubus Academy (SAIA for short). Before her time, most Cubi were taught simply by their clans teachers and were often sent out into the world with not nearly the experience or time to survive the growing number of adventurers. Before the Academy, most Cubi were quite crude in their methods as many of the demon race. Fa'Lina, sensing how their entire race was beginning to be threatened, banded together some of the most intelligent and renowned Cubi teachers she could find, and she formed the first and only Cubi school which has to this day remained safe and hidden from all other races.

SAIA is generally the only place where the various clans(some of which have long-standing grudges) will gather on neutral terms in the pursuit of education. Employing various classes and cultures, the Cubi race evolved rapidly from a dangerous threat to dreams and beings...to an even greater threat to dreams and beings. But at least its an attractive cultured well-dressed threat.`
        }
    ]
  },
  {
    name: 'Undead',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Undead.gif',
    attributes: [
      { label: 'Key Features', value: 'Missing and/or Damaged limbs' },
      { label: 'Eyes', value: 'Glowing' },
      { label: 'Magic', value: 'Dark-oriented' },
      { label: 'Lifespan', value: 'Unknown' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `One of the newest races to be accepted as a race, the Undead race has a lot of issues to work out. Probably the most avoided of all the races, it really is somewhat a shame as the Undead race is probably the nicest and most accepting race of creatures. This likely stems from the fact almost all the Undead were once living beings in some form and as such feel a slight tie to their non-magical kin.

The Undead do not need to eat, sleep, drink, or even breath. The magical forces that keep them animate have more or less put their entire internal structures in a form of stasis. The only exception is their brain which is needs to be in tact to function. While unable to reproduce normally, the Undead can gain more members to their race simply by infecting another race via a lethal bite. Simply being scratched or bitten by an Undead won't kill a person, if the person dies within 24 hours of the injury they will soon rise up as an undead themselves. Perhaps this is why the Undead race face a good deal of prejudice and persecution as many people fear that the simplest of touches from an Undead could cause them to become one of them.

It should be noted that the main reason the Undead don't eat is that all food tastes like nothing to them...with the only exception being living flesh. However the concept of eating a living being is often so repulsive to many undead that some commit re-suicide. This fact along with others only adds to the general creepiness of the race. The Undead have recently gathered and formed an island city called Trik'na Island, where many Undead often leave to avoid an untimely demise at adventurers. Without needing to eat or sleep, the city is actually quite prosperous and welcome to visitors though very few ever go out of fear/dislike.`
      },
      {
        title: 'History',
        content: `The Undead race is the most well-known case of species creation when a powerful Demon decided to use a spell to cause the very dead of the planet to rise and form into an unstoppable army. However he made a major oversight in that while the dead did rise up, they still retained all memories and personalities of their former lives thus many had no real desire to become a grunt in an army against their living friends. However many beings were very uncomfortable with the concept of their dead relatives and friends coming back and so the majority of Undead left their homeland in search of a place to call home. However there are a few Undead who still make their home and have somewhat reclaimed their old "lives".

Another important event was when a cult of Undead grouped together and went about in an attempt to convert the countryside. This short-lived but infamous event still lurks on the minds of many beings and only helped to further wedge a gap between the races.

The Undead is the second of the Creature races to be accepted into the Creature council instead of joining when it started.`
      },
      {
        title: 'Strengths',
        content: `The Undead have no need to eat, breathe, sleep, and have almost an unending supply of endurance. They are also able to fully function even if missing a limb or three. Since they are a new race, only existing for a couple hundred years, no one is sure how long an individual will last. However once undead, the process of decay seems to halt in 98% of the cases, so it is likely they could live as long as many of the other Creature races.`
      },
      {
        title: 'Weaknesses',
        content: `The Undead feel no pain, and in some cases feel nothing at all. This can seem like a bonus, but it is quite frustrating to lose a hand and not even know it is missing. While now capable of magic, the Undead are highly prone to re-dying like any other being if their head is properly damaged.`
      },
      {
        title: 'Notable Figure: Rachel-Rebecca the Third',
        content: `Age 60 (Alive 26, Dead 34), Rachel was attending law school and had a promising future of being a top lawyer...when she sadly became the victim of a terrible and horrendous murder. Left abandoned in a field, it was to her surprise that she arose back up due to the spell. Thanks to her quick thinking, she was able to enlist the aide of her friend and classmate Moira Den to become the first being to successfully win a case over her own murder. Rachel then went on to form the legal workings needed to acknowledge the Undead race as an actual race. It is also her doing to put a severe ruling against any future attempts of species creation.`
      }
    ]
  },
  {
    name: 'Dragon',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Dragon.gif',
    attributes: [
      { label: 'Size', value: 'Usually large' },
      { label: 'Features', value: 'Scales with horns and/or hair' },
      { label: 'Appearance', value: 'Various Colours' },
      { label: 'Magic', value: 'Various, often breath weapons' },
      { label: 'Defense', value: 'Impenetrable hides' },
      { label: 'Lifespan', value: 'Unknown (extremely long)' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `The dragon race is likely one of the oldest and most powerful races in the land of Furrae (The only thing making it an unsure victory being that the Fae aren't so forthcoming with their race history). A single dragon has been known to have the lifespan ten times that of a demon or an angel, and many a dragon has seen the rise and fall of civilizations in their lifetime. Dragons are often diverse in various shapes and sizes, and quite a few have the ability to alter their form to become the size of a regular being or creature. Perhaps it is due to their long lives that many of the dragon race prefer to shy away from the other races and society and instead stick to their own secret groups and organizations.

Or perhaps it is because most dragons and other races don't get along very well. Dragons are powerful, smart, and unfortunately in most cases, very aware of that fact. Because of this, many dragons have a very look-down (no pun intended) opinion of other races. Those that even bother to associate with other races are usually doing it for their own benefit and it isn't uncommon to hear of how a dragon double-crossed a powerful demon or cubi in order to further its own means. It really falls down to a dragon to dragon basis however as some dragons are more than friendly...albeit prone to accidentally landing on the wrong things or places...while others have their names in the history books for terrible deeds.

Dragons are for the most part solitary creatures. Any families or groups seem very adept at hiding themselves. It has been rumoured that the dragons, upon hearing of the Fae's kingdom, worked together in order to create their own special magic kingdom. If it is true or not, no dragon will say.`
      },
      {
        title: 'History',
        content: `As far as any race can remember, there have been dragons. For the most part dragons have been happy to be left to their own devices and not interfere much with the goings on of those around them. However with the rise of other races and their technology, a good deal of dragons have been getting involved in the world affairs. If this is because they feel it is their duty as "guardians of the planet" or because they feel they are "keeping the herd in check"... it really depends on which dragon one asks.`
      },
      {
        title: 'Strengths',
        content: `Dragons have quite a few strengths. Powerful magic plus the ancient knowledge of how to wield it combined with their own bodies natural defense... a dragon could easily take on an army of beings and even a few creature forces if it so chose. Oddly enough, the most often they get into fights are due to the giant gryphons as the gryphon is too territorial and the dragon is too proud to back down.`
      },
      {
        title: 'Weaknesses',
        content: `As far as physical weaknesses go, dragons have none. However due to their egos, most of them have a weakness against games and riddles. Also most dragons due to their age get eccentricities about collecting (or hoarding) certain items. If someone has an object a dragon desires, they almost always have a distinct advantage.`
      },
      {
        title: 'Notable Figure: Balorie',
        content: `Age 57,822, Balorie is considered a very young dragon. Most dragons spend a good bunch of years/centuries/eons trying to earn status, power, knowledge, objects, and respect...a process that is usually long and boring as is. Balorie however decided to side step the process and go a completely different route by creating the first recorded Dragon-creature truce in history. Thanks to Balorie, many Creatures and Beings were able to learn some of the mystic secrets that dragons have been privy to for eons. While this made Balorie unpopular with other dragons, they soon found her invaluable as she was able to gather information and objects in return that a dragon using a conventional method would have missed. Soon after many more dragons broke off and started to work with beings and other creatures. As for Balorie herself, she has long since disappeared... likely living off the wealth she earned on a sunny beach.`
      }
    ]
  },
  {
    name: 'Fae',
    type: 'race',
    attributes: [
      { label: 'Key Features', value: 'Insectlike wings, antennae, forehead gem.' },
      { label: 'Markings', value: 'Bright colours and varied markings.' },
      { label: 'Magic', value: 'Multiple-oriented, highly proficient.' },
      { label: 'Lifespan', value: 'Effectively ageless ("a really long time").' },
    ],
    sections: [
      {
        title: 'General',
        content: `When it comes to magic, the Fae come in on top. Of all the races in Furrae, it seems the Fae are most in touch with the forces and as such wield its power a lot more. Due to magic's instability, this often ends up with the fae being a very diverse and often "eccentric" race. This also tends to account for the various bright colours a Fae will often have.

Despite being one of the oldest races, the Fae tend to be very good at keeping what they know a secret. The actual kingdom the Fae preside in seems to be on another plane of exhistance itself which makes travel to it impossible to any non-Fae. It is known that there is a monarchy involved, but from what has been gathered, the monarchy is more a figurehead and whimsy than any serious attempt at government.

The Fae are able to shift their appearance quite easily and one can often tell a Fae's mood based on their wings and antenna. Most don't try to press a Fae's mood though as angry Fae tend to equal large chunks of land exploding. Somewhat chaotic and some would even say a bit crazy, the Fae go about doing things based on their own whimsy. One thing of note is that many Fae(likely due to the fact they live so long) will often play roles and take on a story as if in a theatre play. Choosing a life of adventurer, lover, savage, they will set themselves into certain guidlines and limits to play out according to their chosen field. Whatever the role and limits are, the Fae sets themselves to that guide very strictly, so far as even allowing themselves to be "killed" for the sake of the great theatre. It does seem though that death on the plane of Furrae is only temporary as there have been many Fae who supposedly died but later return only to start a new role on a new stage...

No one is quite sure why the Fae do what they do, as they seem to be quite capable of wielding a great deal of power(much to the frustration of the other races). For whatever reason, the Fae are what they are.`
      },
      {
        title: 'History',
        content: `The Fae have more or less been a background in history, preferring to offer aid at the strangest times and places. It was because of them that the great Pheonix Temple in the desert exists as the Fae were the ones to create a magical fountain there providing limitless water. It was also the Fae's doing that for 200 years dandelions could grow on concrete. History seems full of things that happen because a Fae felt like it...`
      },
      {
        title: 'Strengths',
        content: `If it's magic, the Fae got a handle on it. No one has ever actively fought a Fae long enough to gauge any strength/weakness.`
      },
      {
        title: 'Weaknesses',
        content: `It seems all weaknesses will be intentional and as such will vary.`
      },
      {
        title: 'Notable Figure (Albanion)',
        content: `Age unknown, Albanion is one of the few Fae who seems to play an active part in the world of Furrae. A spokesperson for Peace, he has been one of the more active voices in trying to build bridges between the Creature and Beings race and it is likely due to him that the Beings/Creature Council hasn't fallen apart yet. It is unknown if this is simply him playing a role, as there is a ancient tablet describing an Albanion way back in ancient times who caused the destruction of an entire race of Mythos over who invented the yo-yo...`
      }
    ],
  },
  {
    name: 'Mythos',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Mythos.gif',
    attributes: [
      { label: 'Limbs', value: 'Multiple (?)' },
      { label: 'Eyes', value: 'Multiple (?)' },
      { label: 'Size', value: 'Varying (tiny-huge)' },
      { label: 'Magic', value: 'Various-oriented' },
      { label: 'Key Feature', value: 'General oddness' },
      { label: 'Lifespan', value: '15,000 to 100,000+ years' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `The Mythos is a very hard to describe race since it consists of multiple races, with each group showing unique traits and abilities. Some might have multiple limbs, while others have multiple heads. They can be smaller than a breadbox and bigger than a house. Some are friendly and peaceful, while others give the demon race a run for its money as far as fierceness goes.

It is because of such diversity that many have a hard time dealing with Mythos as confusion can run abound. One gets the feeling that the Mythos race is almost a boiling pot of "wierd freaky critters" that don't fit into other easily identified categories. Regardless of their oddness, many Mythos are quite the potent magic users and seem to have very close ties to magical lore. Many of the spells in circulation where created and tested by various Mythos, as well as many of the magical devices that exist. Since no two groups are alike, many alliances are made and broken to non-Mythos groups. Some Mythos prefer the company of creatures while others prefer to live amongst urban cities of beings. While a good deal of Mythos do many great things for all societies, their darker nastier kin are often the most likely source of trouble alongside the demon race.`
      },
      {
        title: 'History',
        content: `For the longest time the Mythos race was engaged in civil war...back before many records were kept even. However, thousands of years ago a group of high-powered and intelligent leaders soon rose up and managed to unite the various races under a single race title thus allowing the Mythos a role in the councils. Sadly a darker part of that history was the inevitable genocide of the groups who didn't join into the alliance. Some would claim it was for the best, others not...such is the nature of history. Even today there are still echoes of Mythos races living in hiding from not only modern civilization, but their own kind out of fear despite the intolerance of such beginnings having long since faded away.`
      },
      {
        title: 'Strengths',
        content: `It tends to vary on the mythos. Some are super-fast, some can defy gravity, some can withstand extreme heat or cold...almost all have some element of magic but in the end it boils down to which group they are from.`
      },
      {
        title: 'Weaknesses',
        content: `Like strengths, it will vary greatly. Many adventurers hold a great deal of knowledge of the various mythos that exist and their strengths/weaknesses. So do many libraries...and both tend to be rather long-winded.`
      },
      {
        title: 'Notable Figure: Zingauru',
        content: `Age 24,729, Zingauru is one of the first creatures known to start recording the innerworkings of spells. Before then, most magic was a traditional hand-down from generation to generation. Thanks to Zingauru and other Mythos of his kind though, they were able to start rationalizing a basic science to the inner-workings of spells and how to manipulate the raw energy to create various new spells. His books on the matter are some of the most respected works regarding spellcraft and many magical schools use them now to teach students the art of magic.`
      }
    ]
  },
  {
    name: 'Insectis',
    type: 'race',
    image: 'https://missmab.com/Demo/Images/D_Insectis.gif',
    attributes: [
      { label: 'Exoskeleton', value: 'Hard' },
      { label: 'Key Features', value: 'Large antenni, claws/stinger' },
      { label: 'Magic', value: 'Earth/Fire-oriented' },
      { label: 'Diet', value: 'Vegetarian' },
      { label: 'Lifespan', value: 'Varies by caste (13-900+ years)' },
    ],
    sections: [
      {
        title: 'General Overview',
        content: `It isn't too hard to guess where the Insectis race got it's name from. A large hivelike civilization, the Insectis race lives deep underground in secret catacombs. There is not a good deal of information about them as they are one of the most antisocial races of all Creatures, only coming to the surface to trade with select few or engage in important council meetings. The only time the Insectis even cross the attention of anyone is when mining companies are unfortunate enough to find themselves too close to an Insectis tunnel. The punishment for infringing on their territory is severe with few to no survivors.

The Insectis view the underground world as their entire kingdom, and any who dare enter it a tresspasser (save for particular sections which are given allowance by them) It is known that there is a Queen (or Queens?) who rules over the entire group but the actual rulings and innerworkings are left a mystery. For the most part, the race is quite happy to leave the surface to those above and to be left alone in peace.

It is known however the Insectis love glittering things like gold and gems, so it isn't uncommon for them to be found mining in the very areas a would-be hotspot is. There is only one thing the race seems to adore more than gold and jewels, and that is feathers. The softness and bright colours seem to excite most Insectis and they are most happy to trade riches of some wealth in exchange for rare and exotic feathers. It is also for this reason most winged races tend to avoid going underground since many a time an adventurer with lovely wings has turned up missing around the Insectis.`
      },
      {
        title: 'History',
        content: `The Insectis don't have a much recorded history available to the outside world. They seem on average to dislike and avoid alliances and contact with most races save for the necessary ones. The only exception to this rule is the Mer race, which the Insectis seem to have a very friendly relationship and alliance with. Underground there are quite a few water passageways built to allow the Mer race to travel to various locations. Many trade practices formed by other races with the Insectis were often done by the Mer race's suggestion.`
      },
      {
        title: 'Strengths',
        content: `The Insectis can take quite alot in their element. Able to withstand extreme temperatures, lack of air, massive pressure...they are built to handle the worst that the underground can offer. They also show an amazing ability to evolve and adapt to their situation in a single generation.`
      },
      {
        title: 'Weaknesses',
        content: `Since there are few encounters with the race, weaknesses are hard to find. And any that are discovered seem to disapeer after a generation or so. It is known that many Insectis are single-minded without tact though, so they can also be incredibly frustrating. Thankfully most Insectis have little to no interest in other races thus any real problems with them have been next to none.`
      },
      {
        title: 'Notable Figure: ChkChkTia',
        content: `Age 244, ChkChkTia is one of the queens children who often acts as a speaker for the Queen's behalf since the Queen herself refuses to bother making an appearance herself. He seems on average to be the more polite and sympathetic of the Insectis speakers and it is because of him that any information on the Insectis race is known. A bit timid and seemingly paranoid despite being the Queen's favorite (this is only known because on average a Speaker for the Queen has a life expectancy of 2 meetings, where at ChkChkTia has been a visitor to the surface for over a hundred years). Not really a notable figure, but in the case of the Insectis, he is almost the only real figure the surface has to identify the race with...which might be the reason he is still about as what better image to present to the outside world than a friendly but meek Insectis.`
      }
    ]
  },
  { name: 'Were', type: 'race', attributes: [{ label: 'Classification', value: 'Shapeshifter' }], sections: placeholderSection },
  { name: 'Phoenix (A)', type: 'race', attributes: [{ label: 'Classification', value: 'Mythical Bird' }], sections: placeholderSection },
  { name: 'Phoenix (B)', type: 'race', attributes: [{ label: 'Classification', value: 'Mythical Bird' }], sections: placeholderSection },
  { name: 'Gryphon (A)', type: 'race', attributes: [{ label: 'Classification', value: 'Mythical Beast' }], sections: placeholderSection },
  { name: 'Gryphon (B)', type: 'race', attributes: [{ label: 'Classification', value: 'Mythical Beast' }], sections: placeholderSection },
  { name: 'Gryphon (C)', type: 'race', attributes: [{ label: 'Classification', value: 'Mythical Beast' }], sections: placeholderSection },
  { name: 'Being', type: 'race', attributes: [{ label: 'Classification', value: 'Civilized Race' }], sections: placeholderSection },
  { name: 'Human', type: 'race', attributes: [{ label: 'Classification', value: 'Mortal' }], sections: placeholderSection },
  
  // Classes
  { name: 'Mows', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Livestock', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Pygmy Shrews', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Warp-Aci', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Twinks', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Amazons', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  { name: 'Arachspearians', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
  {
    name: 'Shaman',
    type: 'class',
    attributes: [
      { label: 'Classification', value: 'Mortal, Magic User' },
      { label: 'Primary Trait', value: 'Spirit Communication' },
      { label: 'Tools', value: 'Staffs, Totems, Natural Reagents' },
      { label: 'Role', value: 'Healer, Spiritual Guide, Warrior' },
    ],
    sections: [
        {
            title: 'Overview',
            content: `A Shaman is not a species, but a practitioner of a specific form of magic that involves communing with spirits and the natural world. Shamans draw their power from the elements and the spiritual energy that flows through all living things. They act as intermediaries between the physical and spiritual realms.`
        },
        {
            title: 'Abilities',
            content: `Shamans are versatile magic-users. Their abilities can include healing wounds, enhancing the physical attributes of themselves and others (buffs), calling upon elemental forces like lightning or earthquakes, and summoning spirit allies to aid them in battle. The strength of a shaman is tied to their connection with the spirits and the balance of the natural world around them.`
        },
    ],
  },
  { name: 'Drakes', type: 'class', attributes: [{ label: 'Classification', value: 'Class' }], sections: placeholderSection },
];